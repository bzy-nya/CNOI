#include "testlib.h"
#include<bits/stdc++.h>

typedef unsigned long long ULL;
typedef std::vector<std::string> SEQ;
typedef std::string STR;

SEQ split( std::string _par, char _sgn )
  { SEQ _rat = SEQ();
	STR _rem = STR();
	
    for( char __c : _par )
      { if( __c = _sgn ) _rat.push_back( _rem ), _rem = "";
	    else _rem += __c; }
	
	if( _rem != "" ) _rat.push_back( _rem );
	
	return _rat; }

ULL to_ULL( std::string _str ) 
  { ULL _rat = 0;
	
	for( char __c : _str )
	  { ( _rat *= 10ull ) += (ULL)( __c - '0' ); }
	
	return _rat; }

bool isPw2( ULL x )
  { return !( x & (x - 1ull) ); }

std::map<ULL, bool> MP;

int main(int argc, char* argv[]) {
    registerTestlibCmd(argc, argv);
	
	ULL n = inf.readLong();
	ULL S = 0, T = (1ull << n) - 1ull;
	ULL N = ouf.readLong();
	
	if( N != n ) quitf( _wa, "Count pathes wrongly." );
	
	ouf.readEoln();
	
    while( n -- ) {
    	std::string path = ouf.readLine();
    
    	ULL _lst = 0;
    	
    	for( auto N : split( path, " " ) )
    	  { ULL _now = to_ULL( N );
    		if( _now != S and _now != T and MP[_now] ) 
			  { quitf( _wa, "Passes crossing" ); }
    	    if( !isPw2( _now ^ _lst ) ) 
			  { quitf( _wa, "Wrong path format" ); }
    	    _lst = _now; MP[_now] = true; }
    	
    	if( _lst != T ) quitf( _wa, "Wrong path ending" );
	}
	
	quitf( _ok, "Accepted" );
	
    return 0;
} 
